
public class Searcher extends Thread{

}
