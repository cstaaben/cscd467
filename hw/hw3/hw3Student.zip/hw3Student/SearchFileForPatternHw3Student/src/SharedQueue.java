
import java.util.LinkedList;
import java.util.Queue;


public class SharedQueue {

}
