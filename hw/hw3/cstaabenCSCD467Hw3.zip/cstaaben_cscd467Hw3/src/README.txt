Author: Corbin Staaben
CSCD 467 Hw 3
Description: Unzip the submitted cstaabenCSCD467Hw3.zip file to get the cstaaben_cscd467Hw3 folder.
    To compile:
        cd cstaaben_cscd467Hw3/src
        javac *java
    To run:
        java ParallelSearchCoarse fileName pattern