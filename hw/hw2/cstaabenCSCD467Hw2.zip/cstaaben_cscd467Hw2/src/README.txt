Author: Corbin Staaben
Description: unzip the submitted cstaabenCSCD467Hw2.zip file to get the cstaaben_cscd467Hw2 folder.
            To compile: Execute the following commands
                cd cstaaben_cscd467Hw2/src
                javac *java

            To run: Execute the following commands
                java MyPrimeTest