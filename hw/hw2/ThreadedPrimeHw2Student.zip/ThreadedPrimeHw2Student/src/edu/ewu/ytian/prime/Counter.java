package edu.ewu.ytian.prime;

public class Counter {
	private int c = 0;

    public synchronized void increment( int n) {
        // write me here
    }

    public synchronized int total() {
        // write me here
    }
}
