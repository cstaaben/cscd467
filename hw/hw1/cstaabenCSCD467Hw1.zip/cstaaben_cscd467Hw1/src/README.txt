Corbin Staaben
Description: Unzip submitted cstaabenCSCD467hw1.zip to get cstaaben_cscd467Hw1 folder.
To compile:
    cd cstaaben_cscd467Hw1/src
    javac *java
To run:
    java Hw1Driver