Author: Corbin Staaben
CSCD 467 Lab 3
Description: Unzip the submitted cstaabenCSCD467Lab3.zip folder to get cstaaben_cscd467Lab3
    To compile, execute these commands:
        cd cstaaben_cscd467Lab3/src
        javac *java
    To run:
        java Lab3