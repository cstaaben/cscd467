CSCD 467 Lab 2
Author: Corbin Staaben
Description: uznip cstaabenCSCD467Lab2.zip to get the folder cstaaben_cscd467Lab2
    To compile execute the following commands:
        cd cstaaben_cscd467Lab2/src
        javac *java
    To run:
        java Driver